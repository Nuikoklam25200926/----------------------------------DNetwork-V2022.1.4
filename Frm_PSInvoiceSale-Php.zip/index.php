<?php
require_once "stimulsoft/helper.php";
?>
<!DOCTYPE html>

<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Frm_PSInvoiceSale.mrt - Viewer</title>
	<link rel="stylesheet" type="text/css" href="css/stimulsoft.viewer.office2013.whiteblue.css">
	<script type="text/javascript" src="scripts/stimulsoft.reports.engine.pack.js"></script>
	<script type="text/javascript" src="scripts/stimulsoft.reports.export.pack.js"></script>
	<script type="text/javascript" src="scripts/stimulsoft.viewer.pack.js"></script>

	<?php
		StiHelper::init("handler.php", 30);
	?>
	<script type="text/javascript">
		function Start() {
			Stimulsoft.Base.StiLicense.key =
				"6vJhGtLLLz2GNviWmUTrhSqnOItdDwjBylQzQcAOiHmU+eX0wil9/sy07msOHI4eIU/RPEckYL7DMCiZ" +
				"TIMgPSgUBwmGsEIeg6DyiRQeAtRGJRW44pDi0oUKVRVYrAIm0gGGXCOmGBdyP79TwlZdBrTYBTvuE4JW" +
				"7iaYL7JoT9ANYDBr9AwIAPvvk56sOPkoxf05bjPjhxmOalh3ntwPq05Q3zscXamjBJd5kDMo9nQ1d5+/" +
				"TmCWuZioDu0ZwgFKqOT3FVrh5hSdtjGUVyedPI/3HSP/JE21h18mDkmTDGdrut/KPTM0IDUbQrn9VN1y" +
				"wzKm5BWlTDTFZIZCFutwiYGSDNolFKUSCCZmXmWtVqqWNGTCIac7LRdWPHkJxEWkONXuEXflNZ5dbyuF" +
				"oxw3wOtcRrv4ziAkdEhNR9LW7xpdsOHZk/pZdEaib1Qyib8SimJNS4UclqgnzzbtAOJR9liMCAfG9Gqs" +
				"Y7GjDgmR2TdvH83FfFqp2H28flM41TM7EXriJxPYBRozBdMTWfI9B9cuBE2Oi/PN+Y5gkqf1JYDrtn50" +
				"J64+mWNmCYGgQNKsXQNVsJR7dFiq0JEYxeaHekDIlxjhUtxXYurSuC8YMtIVmSxQNc+XaQ8/IGMFbyAt" +
				"4VVn9gXdLTC9nprfnUfLc3Ks+QnpMphK3yWv2BLDqrfA3pCNDKdyeoh7E71jyxt8XndnNVvk2b1f8p6H" +
				"H+ZD8HGQcMnb5i+/EgQ7VN9ek0LP4XeM6IEO30FHtisD0a61Gvphg5wO++Ns62X4S/yW6myeJBuMnvCl" +
				"lQPOjDtjODk2EjP+p6AVoV65ulvUymTQA0chPy7BjPAJJbOLadSFEL75r2/As2KAR5YSzpVd3HQy9UCz" +
				"7YnwEVEg1I6m0FPKN6r7qmi1K/eNyfhgVSzeCUwVd2pEDoRhOoF/KknLBWPIbKy4fEDdQfwlH6xgcBpH" +
				"tLCZZWPq8AYZ+JxJt7m/hz29SF8StqLD2gwwnctbNxR2m1mz213uwMySBelShgcM21Fh3IsgKHF6aQst" +
				"+oZY3OMqei/t2FKpagksoi/RTDs=";

			Stimulsoft.Base.Localization.StiLocalization.setLocalizationFile("localization/en.xml", true);

			var report = Stimulsoft.Report.StiReport.createNewReport();
			report.loadFile("reports/Frm_PSInvoiceSale.mrt");

			report.dictionary.variables.getByName("SP_nLang").valueObject = "1";
			report.dictionary.variables.getByName("nLanguage").valueObject = 1;
			report.dictionary.variables.getByName("SP_tCompCode").valueObject = "00001";
			report.dictionary.variables.getByName("SP_tCmpBch").valueObject = "00001";
			report.dictionary.variables.getByName("SP_nAddSeq").valueObject = 3;
			report.dictionary.variables.getByName("SP_tDocNo").valueObject = "S22000010000003";
			report.dictionary.variables.getByName("SP_tStaPrn").valueObject = "1";
			report.dictionary.variables.getByName("SP_tGrdStr").valueObject = "";
			report.dictionary.variables.getByName("SP_tDocBch").valueObject = "00001";

			var options = new Stimulsoft.Viewer.StiViewerOptions();
			options.appearance.fullScreenMode = true;
			options.toolbar.displayMode = Stimulsoft.Viewer.StiToolbarDisplayMode.Separated;
			
			var viewer = new Stimulsoft.Viewer.StiViewer(options, "StiViewer", false);

			viewer.onPrepareVariables = function (args, callback) {
				Stimulsoft.Helper.process(args, callback);
			}

			viewer.onBeginProcessData = function (args, callback) {
				Stimulsoft.Helper.process(args, callback);
			}

			viewer.report = report;
			viewer.renderHtml("viewerContent");
		}
	</script>
</head>
<body onload="Start()">
	<div id="viewerContent"></div>
</body>
</html>