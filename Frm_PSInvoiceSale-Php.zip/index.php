<?php
require_once "stimulsoft/helper.php";
?>
<!DOCTYPE html>

<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Frm_PSInvoiceSale.mrt - Viewer</title>
	<link rel="stylesheet" type="text/css" href="css/stimulsoft.viewer.office2013.whiteblue.css">
	<script type="text/javascript" src="scripts/stimulsoft.reports.engine.pack.js"></script>
	<script type="text/javascript" src="scripts/stimulsoft.reports.export.pack.js"></script>
	<script type="text/javascript" src="scripts/stimulsoft.viewer.pack.js"></script>

	<?php
		StiHelper::init("handler.php", 30);
	?>
	<script type="text/javascript">
		function Start() {
			Stimulsoft.Base.StiLicense.key =
				"6vJhGtLLLz2GNviWmUTrhSqnOItdDwjBylQzQcAOiHmCLAaNCrqRXKrY4f5DdoWaormo4VYMSzxCE6xE" +
				"vk2OT2uWD5EV4J0A4jKGHqBqnjj1KocEnWy5FsTHnvyBA1QPQFEqoF2Dh9mKHejXHOk/TJRbfiukeBc1" +
				"J0SacNeiphCgzgmQ12nJZFPntD6EPOQfn8CWBloytP+SBu5ton6CHyvQE2wuUdNM22WsX8B40Wtz5OMs" +
				"WDMopmJkolXesHGBbOUHAkSy5kPh0ENO/5PlLP1nVoKak/JApm+HDfjmsFOzVysNJkacUHXQ2CFD4cEv" +
				"1jlEgDdNiajhW22m4U+6gK6diwIUo+uyPjvMIrUuQeFuFrSpgmm2b7s9a9glnpOqfhaRkQ4dGWQJgc2U" +
				"coLemS/fwsTDeC1U5f6Zqpe2DB5nQ1EQmbO5O5ots5aExf+NZqzK+b93KNSilwpvFnJ4qGgzT8PTmTZu" +
				"/4IMKGkNq4Bq4e9qK1tstDQOsT2iFE9KWMp3+B8Zi9K+k9O33rJRrwYKtFmW7Q2BvzLn/6qYfvTG1Ywe" +
				"86IA+QwttnC5pCJ5mbeWUkMGZr6ViiqGqzjhirfoO+QhkifgizqHsZ5WKpXwpa9KO6qYgiXIFrPtwwVp" +
				"hDoS2DH/8cPRffa5drSiQoDA/mCeWgu5EFEsRVALgEvkchA1XDc2SgRCUC34royDOjP5B/uLwDK1v7a8" +
				"GANO96MJnBAcg8GW1uftg/QsGsnyNi8hH1SXYrivyL3Z/7ccFeVsM2GsukgATr/HzIoCqQh7BMyl6rfj" +
				"6AUtySgZ+VaTd1wYcN4wazYgUTSxD0v1Wgvdyq1GLlWnFL1vh0mvg0y5LDiUs0op0hv+mp1xAWsiHIl8" +
				"iMS5kf7dvnkRd845QoUjnNevWIdtWqKTphVMBnqSkBMD9E7YjfaGjRK8G2d7skBREsmZC5ubjSEr77vZ" +
				"h8sHjXB55W6y+ab/DDT0/2PnE9SDGF+Vpt/D19DRp/fG+u/3g8c1/+pwjB9hmX3mbkAPaekqXgb62OiK" +
				"C3AfDUZ2nhrY4PX3QAatxeF3ZYA=";

			Stimulsoft.Base.Localization.StiLocalization.setLocalizationFile("localization/en.xml", true);

			var report = Stimulsoft.Report.StiReport.createNewReport();
			report.loadFile("reports/Frm_PSInvoiceSale.mrt");

			report.dictionary.variables.getByName("SP_nLang").valueObject = "1";
			report.dictionary.variables.getByName("nLanguage").valueObject = 1;
			report.dictionary.variables.getByName("SP_tCompCode").valueObject = "00001";
			report.dictionary.variables.getByName("SP_tCmpBch").valueObject = "00001";
			report.dictionary.variables.getByName("SP_nAddSeq").valueObject = 3;
			report.dictionary.variables.getByName("SP_tDocNo").valueObject = "S22000010000003";
			report.dictionary.variables.getByName("SP_tStaPrn").valueObject = "1";
			report.dictionary.variables.getByName("SP_tGrdStr").valueObject = "";
			report.dictionary.variables.getByName("SP_tDocBch").valueObject = "00001";

			var options = new Stimulsoft.Viewer.StiViewerOptions();
			options.appearance.fullScreenMode = true;
			options.toolbar.displayMode = Stimulsoft.Viewer.StiToolbarDisplayMode.Separated;
			
			var viewer = new Stimulsoft.Viewer.StiViewer(options, "StiViewer", false);

			viewer.onPrepareVariables = function (args, callback) {
				Stimulsoft.Helper.process(args, callback);
			}

			viewer.onBeginProcessData = function (args, callback) {
				Stimulsoft.Helper.process(args, callback);
			}

			viewer.report = report;
			viewer.renderHtml("viewerContent");
		}
	</script>
</head>
<body onload="Start()">
	<div id="viewerContent"></div>
</body>
</html>